# handler.py

import numpy as np


def matrix(event):
    cap = 10000000 #10 millions
    a = np.arange(cap).reshape((int(cap / 50),-1))

    
    return {"array" : np.array2string(a)}


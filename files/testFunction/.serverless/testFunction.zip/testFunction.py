
def testFunction(params):
    return {"message": "Top secret Hello world!"}